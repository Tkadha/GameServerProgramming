#include "common.h"

HANDLE h_iocp;