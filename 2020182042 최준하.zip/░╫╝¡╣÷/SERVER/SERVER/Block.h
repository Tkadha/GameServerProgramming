#pragma once

constexpr int Block_Count = 20000;
static void set_block();



